song = "";
song_2 = "";
leftwristX = 0;
rightwristX = 0;
leftwristY = 0;
rightwristY = 0;
leftWristScore = 0;
status_1 = "";

function preload(){
    song = loadSound("music.mp3");
    song_2 = loadSound("music2.mp3");
}   

function setup(){
    canvas = createCanvas(600,500);
    canvas.position(450,200);

    camera = createCapture(VIDEO);
    camera.hide();

    posenet = ml5.poseNet(camera,modelLoaded);
    posenet.on('pose',gotPoses);
}

function modelLoaded(){
    console.log("ModelLoaded");
}

function gotPoses(results){
    if(results.length > 0){

        leftWristScore = results[0].pose.keypoints[9].score;
        console.log("left wrist score = " + leftWristScore + "right wrist score = " + rightWristScore);
        
        leftwristX = results[0].pose.leftWrist.x;
        leftwristY = results[0].pose.leftWrist.y;
        console.log("leftwristX = " + leftwristX +",leftwristY = " + leftwristY);

        rightwristX = results[0].pose.rightWrist.x;
        rightwristY = results[0].pose.rightWrist.y;
        console.log("rightwristX = " + rightwristX +",rightwristY = " + rightwristY);
    }
}

function draw(){
    image(camera,0,0,600,500);

    fill("red");
    stroke("red");

    if(leftWristScore > 0.2){

        circle(leftwristX,leftwristY,20);

        num = Number(leftWristY);

        remove_decimal = floor(num);

        volume = remove_decimal/500;

        document.getElementById("volume_lbl").innerHTML = "Volume = " + volume;

        song.setVolume(volume);
    }

    if(rightWristScore > 0.2){

        circle(rightwristX,rightwristY,20);

        if(rightWristScore > 0 && rightWristScore <= 100){

            document.getElementById("speed_lbl").innerHTML = "Speed = 0.5x";
            song.rate(0.5);
        }

        else if(rightWristScore > 100 && rightWristScore <= 200){

            document.getElementById("speed_lbl").innerHTML = "Speed = 1x";
            song.rate(1);
        }

        else if(rightWristScore > 200 && rightWristScore <= 300){

            document.getElementById("speed_lbl").innerHTML = "Speed = 1.5x";
            song.rate(1.5);
        }

        else if(rightWristScore > 300 && rightWristScore <= 400){

            document.getElementById("speed_lbl").innerHTML = "Speed = 2x";
            song.rate(2);
        }

        else if(rightWristScore > 400){

            document.getElementById("speed_lbl").innerHTML = "Speed = 2.5x";
            song.rate(2.5);
        }
    }
}